import install_web_app
import run_app

if __name__ == "__main__":
    install_web_app.main()
    run_app.main()
